MILES & MEMORIES – NORMAL WEBSITE
==================================
This folder is a standard static website.

Upload ALL files and folders inside this folder to any normal web hosting
(public_html / www / htdocs, depending on your host).

The website does not require Netlify to run.
Keep index.html in the hosting root.

Note: any browser-only package manager/admin features from the original
site are not a secure server-side CMS. For real customer booking data,
connect a proper backend or form service later.
